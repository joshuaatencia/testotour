<?php /* C:\xampp\htdocs\laravel\resources\views/administrador.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.bin.js')); ?>"></script>
    <title>Administrador</title>
    <style>
    body {

background-image: url(<?php echo e(asset('img/fondo.jpg')); ?>); no-repeat center center fixed;
/*background: url(https://dl.dropboxusercontent.com/u/23299152/Wallpapers/wallpaper-22705.jpg) no-repeat center center fixed; */ 
-webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover;
font-family: 'Roboto', sans-serif;
}
h1{
    color:#FBC891;
}
    </style>
</head>
<body>
<?php $__env->startSection("navbar"); ?>


    <div class="container">
    <h1>Lista  de Usuarios</h1>
    <table class="table table-dark">
  <thead>
    <tr>
      <th scope="col">Codigo</th>
      <th scope="col">Usuario</th>
      <th scope="col">Nombre</th>
      <th scope="col">Rol</th>
      <th scope="col">Puntos</th>
      <th scope="col">Accion</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($datos ->idusuario); ?></th>
      <td><?php echo e($datos ->usuario); ?></td>
      <td><?php echo e($datos ->nombre); ?></td>
      <td><?php echo e($datos ->rol); ?></td>
      <td><?php echo e($datos ->puntaje); ?></td>
      <td><a href="/update/<?php echo e($datos->idusuario); ?>"><button>eliminar</button></a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
    </div>
<?php $__env->stopSection(); ?>

</body>
</html>
<?php echo $__env->make("layouts.navbaradmi", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>